import { createFileRoute } from "@tanstack/react-router";
import { KvantApp } from "@/components/kvant/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <KvantApp />;
}
