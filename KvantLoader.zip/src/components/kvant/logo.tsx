export function Logo({ className }: { className?: string }) {
  return <img src="/kvant-logo.jpg" alt="Kvant" className={className} />;
}
