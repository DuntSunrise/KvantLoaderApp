import { useEffect, useState } from "react";
import { LogOut } from "lucide-react";
import {
  CLIENTS,
  canLaunchNative,
  clientIntent,
  formatClock,
  maskedKey,
  type Client,
  type ClientId,
  type Session,
} from "@/lib/kvant";
import { Logo } from "@/components/kvant/logo";

type Phase = "scan" | "opened" | "missing";

type Hunt = {
  id: ClientId;
  lines: string[];
  shown: number;
  phase: Phase;
};

function cx(...parts: Array<string | false | undefined>) {
  return parts.filter(Boolean).join(" ");
}

function huntLines(client: Client) {
  return ["Смотрю устройство", `Ищу ${client.name}`, `Пакет ${client.pkg}`, "Открываю клиент"];
}

export function LoaderShell({ session, onExit }: { session: Session; onExit: () => void }) {
  const [hunt, setHunt] = useState<Hunt | null>(null);
  const scanning = hunt?.phase === "scan";

  useEffect(() => {
    if (!hunt || hunt.phase !== "scan") return;
    const client = CLIENTS.find((item) => item.id === hunt.id);
    if (!client) return;
    let shown = hunt.shown;
    let left = false;
    let finished = false;
    const markLeft = () => {
      if (document.hidden) left = true;
    };
    const onPageHide = () => {
      left = true;
    };
    document.addEventListener("visibilitychange", markLeft);
    window.addEventListener("pagehide", onPageHide);
    const timer = window.setInterval(() => {
      shown += 1;
      if (shown <= hunt.lines.length) {
        if (shown === hunt.lines.length && canLaunchNative()) {
          window.location.assign(clientIntent(client.pkg));
        }
        setHunt((current) => (current && current.phase === "scan" ? { ...current, shown } : current));
        return;
      }
      window.clearInterval(timer);
      finished = true;
      window.setTimeout(() => {
        setHunt((current) =>
          current && current.id === client.id ? { ...current, phase: left ? "opened" : "missing" } : current,
        );
      }, 380);
    }, 520);
    return () => {
      document.removeEventListener("visibilitychange", markLeft);
      window.removeEventListener("pagehide", onPageHide);
      window.clearInterval(timer);
      if (!finished) left = false;
    };
  }, [hunt?.id, hunt?.phase]);

  function start(client: Client) {
    if (scanning) return;
    setHunt({ id: client.id, lines: huntLines(client), shown: 1, phase: "scan" });
  }

  const active = CLIENTS.find((item) => item.id === hunt?.id);

  return (
    <div className="stage">
      <div className="stage-grid" aria-hidden />
      <div className="relative z-20 h-0.5 bg-blue" />
      <header className="sticky top-0 z-20 border-b border-line bg-bg/95">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Logo className="size-11 shrink-0 rounded-xl object-cover" />
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">KvantClient V1</p>
            <p className="font-mono text-xs text-blue">Активировано</p>
          </div>
          <span className="ml-auto hidden h-11 items-center gap-2 rounded-full border border-line px-3 font-mono text-xs sm:inline-flex">
            <span className="size-1.5 rounded-full bg-blue kvant-dot" />
            Активировано
          </span>
          <button
            type="button"
            onClick={onExit}
            aria-label="Выйти и забыть ключ"
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-line bg-surface px-3 text-sm"
          >
            <LogOut className="size-4" aria-hidden />
            <span className="hidden sm:inline">Выйти</span>
          </button>
        </div>
      </header>

      <main className="relative z-10 mx-auto flex w-full min-w-0 max-w-3xl flex-col gap-6 px-4 py-6">
        <Logo className="mx-auto h-52 w-full max-w-xs object-contain" />
        <div>
          <p className="font-mono text-xs tracking-widest text-blue">КЛИЕНТЫ</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">Какую версию открыть</h1>
          <p className="mt-2 max-w-xl text-sm text-muted">
            Кнопка ищет PUBG Mobile на устройстве и открывает её, если эта версия установлена. Ключ {maskedKey()} ·{" "}
            {formatClock(session.at)}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {CLIENTS.map((client) => {
            const on = hunt?.id === client.id;
            return (
              <button
                key={client.id}
                type="button"
                disabled={scanning && !on}
                aria-pressed={on}
                onClick={() => start(client)}
                className={cx(
                  "min-h-28 rounded-2xl border p-5 text-left",
                  on ? "border-blue bg-surface-2" : "border-line bg-surface",
                  scanning && !on && "opacity-60",
                )}
              >
                <span className="font-mono text-xs tracking-widest text-blue">{client.region}</span>
                <span className="mt-2 block text-2xl font-semibold">{client.name}</span>
                <span className="mt-2 block truncate font-mono text-xs text-faint">{client.pkg}</span>
              </button>
            );
          })}
        </div>

        <section className="rounded-2xl border border-line bg-surface p-5" aria-live="polite">
          {!hunt || !active ? (
            <>
              <p className="font-mono text-xs tracking-widest text-blue">ПОИСК</p>
              <p className="mt-2 text-sm text-muted">Выберите версию. Загрузчик проверит устройство и откроет игру.</p>
            </>
          ) : (
            <>
              <p className="font-mono text-xs tracking-widest text-blue">{active.name}</p>
              <ol className="mt-3 space-y-2 font-mono text-sm">
                {hunt.lines.slice(0, hunt.shown).map((line) => (
                  <li key={line} className="text-muted">
                    {line}
                  </li>
                ))}
              </ol>
              {hunt.phase === "opened" ? (
                <p className="mt-4 text-base font-medium text-fg">{active.name} открыт.</p>
              ) : null}
              {hunt.phase === "missing" ? (
                <p className="mt-4 text-sm text-danger">
                  {active.name} на этом устройстве не найден.
                  {canLaunchNative()
                    ? " Установите эту версию PUBG Mobile и нажмите кнопку снова."
                    : " Открытие срабатывает на Android, где клиент уже стоит."}
                </p>
              ) : null}
            </>
          )}
        </section>
      </main>
    </div>
  );
}
