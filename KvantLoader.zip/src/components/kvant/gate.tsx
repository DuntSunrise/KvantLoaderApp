import { useState, type FormEvent } from "react";
import { keyStructure, verdict } from "@/lib/kvant";
import { Logo } from "@/components/kvant/logo";

const MESSAGES = {
  empty: "Введите ключ — без него загрузчик закрыт.",
  shape: "Формат: Kvant-блок-шифр. Проверьте дефисы и регистр.",
  reject: "Этот ключ не совпал с лицензией Kvant.",
} as const;

function cx(...parts: Array<string | false | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function GateScreen({ onAccept }: { onAccept: () => void }) {
  const [key, setKey] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(false);
  const [pending, setPending] = useState(false);
  const parts = keyStructure(key);
  const ready = parts.every((part) => part.ok);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (pending) return;
    const result = verdict(key);
    if (result !== "ok") {
      setError(MESSAGES[result]);
      setShake(true);
      return;
    }
    setError(null);
    setPending(true);
    window.setTimeout(onAccept, 680);
  }

  return (
    <main className="stage">
      <div className="stage-grid" aria-hidden />
      <div className="stage-glow" aria-hidden />
      <div className="relative z-10 mx-auto grid min-h-dvh w-full max-w-6xl lg:grid-cols-2">
        <section className="hidden flex-col justify-between px-12 py-12 lg:flex">
          <p className="font-mono text-xs tracking-widest text-blue">KVANT SYSTEMS</p>
          <div className="kvant-in">
            <Logo className="h-72 w-full max-w-xs object-contain" />
            <h1 className="mt-4 text-4xl font-semibold tracking-tight">
              KvantClient
              <span className="mt-1 block text-xl font-medium tracking-widest text-blue">V1</span>
            </h1>
            <p className="mt-4 max-w-sm text-base text-muted">
              Сначала лицензия. После активации — четыре клиента PUBG Mobile.
            </p>
          </div>
          <p className="font-mono text-xs text-faint">Не активировано</p>
        </section>

        <section className="flex min-w-0 items-center px-5 py-10 sm:px-10 lg:px-12">
          <form
            onSubmit={onSubmit}
            onAnimationEnd={() => setShake(false)}
            className={cx(
              "kvant-in relative w-full max-w-md overflow-hidden rounded-2xl border bg-surface",
              shake ? "kvant-shake border-danger" : "border-line",
            )}
            noValidate
          >
            <span className="absolute inset-y-0 left-0 w-1.5 bg-blue" aria-hidden />
            <div className="p-6 sm:p-8">
              <div className="mb-6 flex items-center gap-3 lg:hidden">
                <Logo className="size-14 rounded-xl object-cover" />
                <div>
                  <p className="font-mono text-xs tracking-widest text-blue">KvantClient V1</p>
                  <p className="text-sm text-faint">Не активировано</p>
                </div>
              </div>

              <div className="flex items-center justify-between gap-3">
                <p className="font-mono text-xs tracking-widest text-blue">KvantClient V1</p>
                <p className="font-mono text-xs text-faint">Не активировано</p>
              </div>
              <h2 className="mt-4 text-2xl font-semibold">Активация лицензии</h2>
              <p className="mt-2 text-sm text-muted">
                Введите ключ. После сверки откроется загрузчик с версиями PUBG.
              </p>

              <label htmlFor="license-key" className="mt-8 block text-xs font-medium tracking-widest text-faint">
                ЛИЦЕНЗИОННЫЙ КЛЮЧ
              </label>
              <input
                id="license-key"
                name="kvant-license"
                value={key}
                onChange={(event) => {
                  setKey(event.target.value);
                  if (error) setError(null);
                  if (shake) setShake(false);
                }}
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                autoComplete="off"
                inputMode="text"
                aria-invalid={error ? true : undefined}
                aria-describedby={error ? "key-error" : "key-hint"}
                placeholder="Kvant-····-········"
                className={cx(
                  "mt-3 h-14 w-full rounded-xl border bg-bg px-4 font-mono text-base text-fg",
                  "placeholder:text-faint",
                  error ? "border-danger" : "border-line focus:border-blue",
                )}
              />

              <ul className="mt-3 flex flex-wrap gap-2">
                {parts.map((part) => (
                  <li
                    key={part.id}
                    className={cx(
                      "rounded-full border px-3 py-1 font-mono text-xs",
                      part.ok ? "border-blue text-blue" : "border-line text-faint",
                    )}
                  >
                    {part.label}
                  </li>
                ))}
              </ul>

              <p id="key-hint" className="mt-3 text-sm text-faint">
                {ready ? "Структура собрана. Регистр символов важен." : "Три части через дефис. Регистр важен."}
                <span className="ml-2 font-mono text-xs">{key.trim().length || 0}</span>
              </p>

              {error ? (
                <p id="key-error" role="alert" className="mt-3 text-sm text-danger">
                  {error}
                </p>
              ) : null}

              <button
                type="submit"
                disabled={pending}
                className="mt-6 flex h-12 w-full items-center justify-center rounded-xl bg-blue-solid text-base font-semibold text-on-blue disabled:opacity-70"
              >
                {pending ? "Сверка ключа…" : "Активировать лицензию"}
              </button>
            </div>
          </form>
        </section>
      </div>
    </main>
  );
}
