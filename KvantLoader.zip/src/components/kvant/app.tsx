import { useEffect, useState } from "react";
import { BOOT_LINES, maskedKey, readSession, writeSession, type Session } from "@/lib/kvant";
import { Logo } from "@/components/kvant/logo";
import { GateScreen } from "@/components/kvant/gate";
import { LoaderShell } from "@/components/kvant/shell";

type Phase = "gate" | "boot" | "app";

export function KvantApp() {
  const [phase, setPhase] = useState<Phase>("gate");
  const [session, setSession] = useState<Session | null>(null);
  const [lines, setLines] = useState<string[]>([]);

  useEffect(() => {
    const saved = readSession();
    if (!saved) return;
    setSession(saved);
    setPhase("app");
  }, []);

  useEffect(() => {
    if (phase !== "boot") return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const step = reduced ? 40 : 280;
    let index = 0;
    let cancelled = false;
    setLines([]);
    const timer = window.setInterval(() => {
      if (cancelled) return;
      index += 1;
      setLines(BOOT_LINES.slice(0, index));
      if (index >= BOOT_LINES.length) {
        window.clearInterval(timer);
        window.setTimeout(() => {
          if (!cancelled) setPhase("app");
        }, reduced ? 40 : 420);
      }
    }, step);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [phase]);

  function accept() {
    const next: Session = { at: Date.now() };
    writeSession(next);
    setSession(next);
    setLines([]);
    setPhase("boot");
  }

  function exit() {
    writeSession(null);
    setSession(null);
    setLines([]);
    setPhase("gate");
  }

  if (phase === "boot") {
    const pct = Math.round((lines.length / BOOT_LINES.length) * 100);
    return (
      <main className="stage">
        <div className="stage-grid" aria-hidden />
        <div className="relative z-10 mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6">
          <Logo className="mb-6 h-40 w-full object-contain" />
          <p className="font-mono text-xs tracking-widest text-blue">KvantClient V1</p>
          <h1 className="mt-3 text-4xl font-semibold">Активировано</h1>
          <p className="mt-3 break-all font-mono text-sm text-muted">{maskedKey()}</p>
          <ul className="mt-8 space-y-2 font-mono text-sm text-muted" aria-live="polite">
            {lines.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
          <div className="mt-8 h-1 overflow-hidden rounded-full bg-surface-2" aria-hidden>
            <div className="h-full bg-blue" style={{ width: `${pct}%` }} />
          </div>
        </div>
      </main>
    );
  }

  if (phase === "app" && session) {
    return <LoaderShell session={session} onExit={exit} />;
  }

  return <GateScreen onAccept={accept} />;
}
