export const LICENSE_KEY = "Kvant-Mvp-Ms829alKWSBkwsb7619";

export const BOOT_LINES = [
  "ключ принят · KvantClient V1",
  "лицензия активирована",
  "загрузчик открыт",
  "клиенты PUBG на месте",
];

const STORAGE_KEY = "kvant.session.v1";

export const CLIENTS = [
  { id: "tv", name: "Pubgm Tv", region: "Тайвань", pkg: "com.rekoo.pubgm" },
  { id: "vn", name: "Pubgm Vn", region: "Вьетнам", pkg: "com.vng.pubgmobile" },
  { id: "kr", name: "Pubgm Kr", region: "Корея", pkg: "com.pubg.krmobile" },
  { id: "gl", name: "Pubgm Gl", region: "Global", pkg: "com.tencent.ig" },
] as const;

export type ClientId = (typeof CLIENTS)[number]["id"];
export type Client = (typeof CLIENTS)[number];

export type Session = {
  at: number;
};

export type KeyVerdict = "empty" | "shape" | "reject" | "ok";

export function verdict(raw: string): KeyVerdict {
  const value = raw.trim();
  if (!value) return "empty";
  if (value === LICENSE_KEY) return "ok";
  const parts = value.split("-");
  const shapeOk =
    parts.length === 3 &&
    parts[0] === "Kvant" &&
    /^[A-Za-z0-9]{2,}$/.test(parts[1] ?? "") &&
    /^[A-Za-z0-9]{8,}$/.test(parts[2] ?? "");
  return shapeOk ? "reject" : "shape";
}

export function keyStructure(raw: string) {
  const parts = raw.trim().split("-");
  return [
    { id: "prefix", label: "Префикс", ok: parts[0] === "Kvant" },
    {
      id: "block",
      label: "Блок",
      ok: parts.length >= 2 && /^[A-Za-z0-9]{2,}$/.test(parts[1] ?? ""),
    },
    {
      id: "cipher",
      label: "Шифр",
      ok: parts.length === 3 && /^[A-Za-z0-9]{8,}$/.test(parts[2] ?? ""),
    },
  ];
}

export function maskedKey() {
  return "Kvant-Mvp-•••7619";
}

export function readSession(): Session | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<Session>;
    if (typeof data.at !== "number") return null;
    return { at: data.at };
  } catch {
    return null;
  }
}

export function writeSession(session: Session | null) {
  try {
    if (!session) localStorage.removeItem(STORAGE_KEY);
    else localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  } catch {
    /* private mode */
  }
}

export function formatClock(t: number) {
  return new Intl.DateTimeFormat("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(t);
}

export function canLaunchNative() {
  return typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent);
}

export function clientIntent(pkg: string) {
  return `intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${pkg};end`;
}
