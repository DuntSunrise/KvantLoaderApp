package com.kvant.loader

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class KeyActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_NAME = "kvant_prefs"
        private const val KEY_ACTIVATED = "activated"

        // MVP: ключ захардкожен. Для продакшена вынести проверку на сервер.
        private const val VALID_KEY = "Kvant-Mvp-Ms829alKWSBkwsb7619"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        if (prefs.getBoolean(KEY_ACTIVATED, false)) {
            goToMain()
            return
        }

        setContentView(R.layout.activity_key)

        val etKey = findViewById<EditText>(R.id.etKey)
        val btnActivate = findViewById<Button>(R.id.btnActivate)
        val tvError = findViewById<TextView>(R.id.tvError)

        btnActivate.setOnClickListener {
            val input = etKey.text.toString().trim()
            if (input == VALID_KEY) {
                prefs.edit().putBoolean(KEY_ACTIVATED, true).apply()
                goToMain()
            } else {
                tvError.visibility = TextView.VISIBLE
            }
        }
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
