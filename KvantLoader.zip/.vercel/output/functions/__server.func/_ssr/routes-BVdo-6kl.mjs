import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as LogOut } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BVdo-6kl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BUILD = "2.4.1";
var BOOT_LINES = [
	"ключ принят · план MVP",
	"лицензия активирована",
	"загрузчик открыт",
	"клиенты PUBG на месте"
];
var STORAGE_KEY = "kvant.session.v1";
var CLIENTS = [
	{
		id: "tv",
		name: "Pubgm Tv",
		region: "Тайвань",
		pkg: "com.rekoo.pubgm"
	},
	{
		id: "vn",
		name: "Pubgm Vn",
		region: "Вьетнам",
		pkg: "com.vng.pubgmobile"
	},
	{
		id: "kr",
		name: "Pubgm Kr",
		region: "Корея",
		pkg: "com.pubg.krmobile"
	},
	{
		id: "gl",
		name: "Pubgm Gl",
		region: "Global",
		pkg: "com.tencent.ig"
	}
];
function verdict(raw) {
	const value = raw.trim();
	if (!value) return "empty";
	if (value === "Kvant-Mvp-Ms829alKWSBkwsb7619") return "ok";
	const parts = value.split("-");
	return parts.length === 3 && parts[0] === "Kvant" && /^[A-Za-z0-9]{2,}$/.test(parts[1] ?? "") && /^[A-Za-z0-9]{8,}$/.test(parts[2] ?? "") ? "reject" : "shape";
}
function keyStructure(raw) {
	const parts = raw.trim().split("-");
	return [
		{
			id: "prefix",
			label: "Префикс",
			ok: parts[0] === "Kvant"
		},
		{
			id: "block",
			label: "Блок",
			ok: parts.length >= 2 && /^[A-Za-z0-9]{2,}$/.test(parts[1] ?? "")
		},
		{
			id: "cipher",
			label: "Шифр",
			ok: parts.length === 3 && /^[A-Za-z0-9]{8,}$/.test(parts[2] ?? "")
		}
	];
}
function maskedKey() {
	return "Kvant-Mvp-•••7619";
}
function readSession() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const data = JSON.parse(raw);
		if (typeof data.at !== "number") return null;
		return { at: data.at };
	} catch {
		return null;
	}
}
function writeSession(session) {
	try {
		if (!session) localStorage.removeItem(STORAGE_KEY);
		else localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
	} catch {}
}
function formatClock(t) {
	return new Intl.DateTimeFormat("ru-RU", {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	}).format(t);
}
function canLaunchNative() {
	return typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent);
}
function clientIntent(pkg) {
	return `intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${pkg};end`;
}
var MESSAGES = {
	empty: "Введите ключ — без него загрузчик закрыт.",
	shape: "Формат: Kvant-блок-шифр. Проверьте дефисы и регистр.",
	reject: "Этот ключ не совпал с лицензией Kvant."
};
function cx$1(...parts) {
	return parts.filter(Boolean).join(" ");
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx$1("relative grid place-items-center", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 100 100",
			className: "kvant-spin absolute inset-0 size-full text-blue",
			"aria-hidden": true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r: "44",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1",
					opacity: "0.35"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "6",
					r: "2.6",
					fill: "currentColor"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r: "28",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.25",
					opacity: "0.7",
					strokeDasharray: "10 12"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono font-medium text-blue",
			children: "K"
		})]
	});
}
function GateScreen({ onAccept }) {
	const [key, setKey] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [shake, setShake] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)(false);
	const parts = keyStructure(key);
	const ready = parts.every((part) => part.ok);
	function onSubmit(event) {
		event.preventDefault();
		if (pending) return;
		const result = verdict(key);
		if (result !== "ok") {
			setError(MESSAGES[result]);
			setShake(true);
			return;
		}
		setError(null);
		setPending(true);
		window.setTimeout(onAccept, 680);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "stage",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stage-grid",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stage-glow",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto grid min-h-dvh w-full max-w-6xl lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "hidden flex-col justify-between px-12 py-12 lg:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-blue",
							children: "KVANT SYSTEMS"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "kvant-in",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-36 text-3xl" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-8 text-7xl font-semibold tracking-tight",
									children: ["Kvant", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-2 block text-3xl font-medium tracking-widest text-blue",
										children: "LOADER"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 max-w-sm text-base text-muted",
									children: "Сначала лицензия. После активации — четыре клиента PUBG Mobile."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-faint",
							children: [
								"сборка ",
								BUILD,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-2 text-faint",
									children: "/"
								}),
								"сверка только в этом браузере"
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "flex min-w-0 items-center px-5 py-10 sm:px-10 lg:px-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit,
						onAnimationEnd: () => setShake(false),
						className: cx$1("kvant-in relative w-full max-w-md overflow-hidden rounded-2xl border bg-surface", shake ? "kvant-shake border-danger" : "border-line"),
						noValidate: true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute inset-y-0 left-0 w-1.5 bg-blue",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6 sm:p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-8 flex items-center gap-3 lg:hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-14 text-lg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs tracking-widest text-blue",
										children: "KVANT"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xl font-semibold",
										children: "Loader"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs tracking-widest text-blue",
										children: "ДОСТУП 01"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs text-faint",
										children: "ПЛАН MVP"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-4 text-2xl font-semibold",
									children: "Активация лицензии"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: "Введите ключ. После сверки откроется загрузчик с версиями PUBG."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "license-key",
									className: "mt-8 block text-xs font-medium tracking-widest text-faint",
									children: "ЛИЦЕНЗИОННЫЙ КЛЮЧ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "license-key",
									name: "kvant-license",
									value: key,
									onChange: (event) => {
										setKey(event.target.value);
										if (error) setError(null);
										if (shake) setShake(false);
									},
									autoCapitalize: "off",
									autoCorrect: "off",
									spellCheck: false,
									autoComplete: "off",
									inputMode: "text",
									"aria-invalid": error ? true : void 0,
									"aria-describedby": error ? "key-error" : "key-hint",
									placeholder: "Kvant-····-········",
									className: cx$1("mt-3 h-14 w-full rounded-xl border bg-bg px-4 font-mono text-base text-fg", "placeholder:text-faint", error ? "border-danger" : "border-line focus:border-blue")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 flex flex-wrap gap-2",
									children: parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: cx$1("rounded-full border px-3 py-1 font-mono text-xs", part.ok ? "border-blue text-blue" : "border-line text-faint"),
										children: part.label
									}, part.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									id: "key-hint",
									className: "mt-3 text-sm text-faint",
									children: [ready ? "Структура собрана. Регистр символов важен." : "Три части через дефис. Регистр важен.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 font-mono text-xs",
										children: key.trim().length || 0
									})]
								}),
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									id: "key-error",
									role: "alert",
									className: "mt-3 text-sm text-danger",
									children: error
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: pending,
									className: "mt-6 flex h-12 w-full items-center justify-center rounded-xl bg-blue-solid text-base font-semibold text-on-blue disabled:opacity-70",
									children: pending ? "Сверка ключа…" : "Активировать лицензию"
								})
							]
						})]
					})
				})]
			})
		]
	});
}
function cx(...parts) {
	return parts.filter(Boolean).join(" ");
}
function huntLines(client) {
	return [
		"Смотрю устройство",
		`Ищу ${client.name}`,
		`Пакет ${client.pkg}`,
		"Открываю клиент"
	];
}
function LoaderShell({ session, onExit }) {
	const [hunt, setHunt] = (0, import_react.useState)(null);
	const scanning = hunt?.phase === "scan";
	(0, import_react.useEffect)(() => {
		if (!hunt || hunt.phase !== "scan") return;
		const client = CLIENTS.find((item) => item.id === hunt.id);
		if (!client) return;
		let shown = hunt.shown;
		let left = false;
		let finished = false;
		const markLeft = () => {
			if (document.hidden) left = true;
		};
		const onPageHide = () => {
			left = true;
		};
		document.addEventListener("visibilitychange", markLeft);
		window.addEventListener("pagehide", onPageHide);
		const timer = window.setInterval(() => {
			shown += 1;
			if (shown <= hunt.lines.length) {
				if (shown === hunt.lines.length && canLaunchNative()) window.location.assign(clientIntent(client.pkg));
				setHunt((current) => current && current.phase === "scan" ? {
					...current,
					shown
				} : current);
				return;
			}
			window.clearInterval(timer);
			finished = true;
			window.setTimeout(() => {
				setHunt((current) => current && current.id === client.id ? {
					...current,
					phase: left ? "opened" : "missing"
				} : current);
			}, 380);
		}, 520);
		return () => {
			document.removeEventListener("visibilitychange", markLeft);
			window.removeEventListener("pagehide", onPageHide);
			window.clearInterval(timer);
			if (!finished) left = false;
		};
	}, [hunt?.id, hunt?.phase]);
	function start(client) {
		if (scanning) return;
		setHunt({
			id: client.id,
			lines: huntLines(client),
			shown: 1,
			phase: "scan"
		});
	}
	const active = CLIENTS.find((item) => item.id === hunt?.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stage",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stage-grid",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "relative z-20 h-0.5 bg-blue" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-bg/95",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 shrink-0 place-items-center rounded-xl border border-line bg-surface font-mono text-sm text-blue",
							children: "K"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-semibold",
								children: "Kvant Loader"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-faint",
								children: ["сборка ", BUILD]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-auto inline-flex h-11 items-center gap-2 rounded-full border border-line px-3 font-mono text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-blue kvant-dot" }), "ЛИЦЕНЗИЯ"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onExit,
							"aria-label": "Выйти и забыть ключ",
							className: "inline-flex h-11 items-center gap-2 rounded-xl border border-line bg-surface px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
								className: "size-4",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Выйти"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative z-10 mx-auto flex w-full min-w-0 max-w-3xl flex-col gap-6 px-4 py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-blue",
							children: "КЛИЕНТЫ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 text-3xl font-semibold tracking-tight sm:text-4xl",
							children: "Какую версию открыть"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 max-w-xl text-sm text-muted",
							children: [
								"Кнопка ищет PUBG Mobile на устройстве и открывает её, если эта версия установлена. Ключ ",
								maskedKey(),
								" ·",
								" ",
								formatClock(session.at)
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: CLIENTS.map((client) => {
							const on = hunt?.id === client.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: scanning && !on,
								"aria-pressed": on,
								onClick: () => start(client),
								className: cx("min-h-28 rounded-2xl border p-5 text-left", on ? "border-blue bg-surface-2" : "border-line bg-surface", scanning && !on && "opacity-60"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs tracking-widest text-blue",
										children: client.region
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-2 block text-2xl font-semibold",
										children: client.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-2 block truncate font-mono text-xs text-faint",
										children: client.pkg
									})
								]
							}, client.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "rounded-2xl border border-line bg-surface p-5",
						"aria-live": "polite",
						children: !hunt || !active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-blue",
							children: "ПОИСК"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Выберите версию. Загрузчик проверит устройство и откроет игру."
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs tracking-widest text-blue",
								children: active.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-3 space-y-2 font-mono text-sm",
								children: hunt.lines.slice(0, hunt.shown).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "text-muted",
									children: line
								}, line))
							}),
							hunt.phase === "opened" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-base font-medium text-fg",
								children: [active.name, " открыт."]
							}) : null,
							hunt.phase === "missing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-sm text-danger",
								children: [
									active.name,
									" на этом устройстве не найден.",
									canLaunchNative() ? " Установите эту версию PUBG Mobile и нажмите кнопку снова." : " Открытие срабатывает на Android, где клиент уже стоит."
								]
							}) : null
						] })
					})
				]
			})
		]
	});
}
function KvantApp() {
	const [phase, setPhase] = (0, import_react.useState)("gate");
	const [session, setSession] = (0, import_react.useState)(null);
	const [lines, setLines] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const saved = readSession();
		if (!saved) return;
		setSession(saved);
		setPhase("app");
	}, []);
	(0, import_react.useEffect)(() => {
		if (phase !== "boot") return;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const step = reduced ? 40 : 280;
		let index = 0;
		let cancelled = false;
		setLines([]);
		const timer = window.setInterval(() => {
			if (cancelled) return;
			index += 1;
			setLines(BOOT_LINES.slice(0, index));
			if (index >= BOOT_LINES.length) {
				window.clearInterval(timer);
				window.setTimeout(() => {
					if (!cancelled) setPhase("app");
				}, reduced ? 40 : 420);
			}
		}, step);
		return () => {
			cancelled = true;
			window.clearInterval(timer);
		};
	}, [phase]);
	function accept() {
		const next = { at: Date.now() };
		writeSession(next);
		setSession(next);
		setLines([]);
		setPhase("boot");
	}
	function exit() {
		writeSession(null);
		setSession(null);
		setLines([]);
		setPhase("gate");
	}
	if (phase === "boot") {
		const pct = Math.round(lines.length / BOOT_LINES.length * 100);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "stage",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stage-grid",
				"aria-hidden": true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-blue",
						children: "KVANT / BOOT"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 text-4xl font-semibold",
						children: "Лицензия активна"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 break-all font-mono text-sm text-muted",
						children: maskedKey()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 space-y-2 font-mono text-sm text-muted",
						"aria-live": "polite",
						children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 h-1 overflow-hidden rounded-full bg-surface-2",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-blue",
							style: { width: `${pct}%` }
						})
					})
				]
			})]
		});
	}
	if (phase === "app" && session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderShell, {
		session,
		onExit: exit
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GateScreen, { onAccept: accept });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KvantApp, {});
}
//#endregion
export { Home as component };
