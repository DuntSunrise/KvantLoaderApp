//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DwXr3SNy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DsGuCBfd.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DsGuCBfd.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-N7b3yhe3.js"]
	}
} });
//#endregion
export { tsrStartManifest };
